﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Room {

    public List<string> doors;
    public List<string> items;

    public Room()
    {
        doors = new List<string>();
        items = new List<string>();
    }
}
