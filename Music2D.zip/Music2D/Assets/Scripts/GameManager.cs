﻿using Completed;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

 
public class GameManager : MonoBehaviour {
	public float levelStartDelay = 0f;
	public float trueDelay = 0f;
    public static GameManager instance = null;
    public BoardManager boardScript;
    public GameObject player;
    private int level = 1;
 
	private Text levelText;
	private GameObject levelImage;

    private Level currentLevel;


	void Awake()
    {
        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(gameObject);
        DontDestroyOnLoad(gameObject);
        boardScript = GetComponent<BoardManager>();
        InitGame();
    }

	private void OnlevelWasLoaded(int index)
	{
		level++;
	}

    void InitGame()
    {
		levelImage = GameObject.Find ("LevelImage");
		levelText = GameObject.Find ("LevelText").GetComponent<Text> ();
		levelText.text = "Game Over";
		levelImage.SetActive (true);
		Invoke ("HideLevelImage", levelStartDelay);

        currentLevel = new Level();
        currentLevel.SetUpLevel(level);

        boardScript.player = player;
        boardScript.SetupScene(currentLevel.rooms[0]);
    }

	private void HidelevelImage()
	{
		levelImage.SetActive (false);
	}

    public void GameOver()
    {
    }

    // Update is called once per frame
    void Update () {
        if(Player.roomToMoveTo != -1)
        {
            boardScript.ClearRoom();
            boardScript.SetupScene(currentLevel.rooms[Player.roomToMoveTo]);
            Player.roomToMoveTo = -1;
        }
        if (Player.goToNextLevel)
        {
            Player.goToNextLevel = false;
            level++;
            currentLevel = new Level();
            currentLevel.SetUpLevel(level);
            boardScript.ClearRoom();
            boardScript.SetupScene(currentLevel.rooms[0]);
        }
	}
}
