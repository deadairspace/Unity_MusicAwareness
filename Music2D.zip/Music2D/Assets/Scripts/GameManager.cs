﻿using Completed;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

 
public class GameManager : MonoBehaviour {
	public float levelStartDelay = 2f;
	public float trueDelay = .1f;
    public static GameManager instance = null;
    public BoardManager boardScript;
    private int level = 1;
 
	private Text levelText;
	private GameObject levelImage;
	private bool doingSetup;

	//private int level = 1;



	void Awake()
    {
        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(gameObject);
        DontDestroyOnLoad(gameObject);
        boardScript = GetComponent<BoardManager>();
        InitGame();
    }

	private void OnlevelWasLoaded(int index)
	{
		level++;


	}
    void InitGame()
    {
		doingSetup = true;
		levelImage = GameObject.Find ("LevelImage");
		levelText = GameObject.Find ("LevelText").GetComponent<Text> ();
		levelText.text = "Game Over";
		levelImage.SetActive (true);
		Invoke ("HideLevelImage", levelStartDelay);

        boardScript.SetupScene(level);
    }

	private void HidelevelImage()
	{

		levelImage.SetActive (false);
		doingSetup = false;

	}
    public void GameOver()
    {
		levelText.text = "You are Close to Find The Key.";
		levelImage.SetActive (true);

        enabled = false;
    }
    // Update is called once per frame
    void Update () {
		
	}
}
