﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level {
    public List<Room> rooms;

    public Level()
    {
        rooms = new List<Room>();
    }


    public void SetUpLevel(int level)
    {
        if(level == 1)
        {
            Room spawnRoom = new Room();
            spawnRoom.items.Add("key");
            spawnRoom.items.Add("exit");
            spawnRoom.items.Add("spawn");

            rooms.Add(spawnRoom);
        }

        if(level == 2)
        {
            //Spawn=0
            //Key=1
            //Empty=2
            //Goal=3

            Room spawnRoom = new Room();
            spawnRoom.items.Add("spawn");
            spawnRoom.doors.AddRange(new string[]{"north:1 key:1", "east:2", "south:3 exit:1"});

            Room northRoom = new Room();
            northRoom.doors.Add("south:0 spawn:1 exit:2");
            northRoom.items.Add("key");

            Room eastRoom = new Room();
            eastRoom.doors.Add("west:0 spawn:1 exit:2 key:2");

            Room southRoom = new Room();
            southRoom.doors.Add("north:0 spawn:1 key:2");
            southRoom.items.Add("exit");

            rooms.Add(spawnRoom);
            rooms.Add(northRoom);
            rooms.Add(eastRoom);
            rooms.Add(southRoom);
        }

        if(level == 3)
        {
            Room room0 = new Room();
            room0.items.Add("spawn");
            room0.doors.AddRange(new string[] { "south:5", "east:6 exit:4", "west:1 key:3" });

            Room room1 = new Room();
            room1.doors.AddRange(new string[] { "east:0 exit:5 spawn:1", "west:2 key:2" });

            Room room2 = new Room();
            room2.doors.AddRange(new string[] { "east:1 exit:6 spawn:2", "north:3", "south:4 key:1" });

            Room room3 = new Room();
            room3.doors.AddRange(new string[] { "south:2 key:2 exit:7" });

            Room room4 = new Room();
            room4.items.Add("key");
            room4.doors.AddRange(new string[] { "north:2 exit:7" });

            Room room5 = new Room();
            room5.doors.AddRange(new string[] { "north:0 exit:5 key:4" });

            Room room6 = new Room();
            room6.doors.AddRange(new string[] { "west:0 key:4", "east:7 exit:3" });

            Room room7 = new Room();
            room7.doors.AddRange(new string[] { "west:6 key:5", "north:8 exit:2" });

            Room room8 = new Room();
            room8.doors.AddRange(new string[] { "south:7 key:6", "east:9", "west:10 exit:1" });

            Room room9 = new Room();
            room9.doors.AddRange(new string[] { "west:8 exit:2 key:7" });

            Room room10 = new Room();
            room10.items.Add("exit");
            room10.doors.AddRange(new string[] { "east:8 key:7" });

            rooms.AddRange(new Room[] { room0, room1, room2, room3, room4, room5, room6, room7, room8, room9, room10 });
        }
    }
}
