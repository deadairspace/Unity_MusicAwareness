﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level {
    public List<Room> rooms;

    public Level()
    {
        rooms = new List<Room>();
    }


    public void SetUpLevel(int level)
    {
        if(level == 1)
        {
            Room spawnRoom = new Room();
            spawnRoom.items.Add("key");
            spawnRoom.items.Add("exit");
            spawnRoom.items.Add("spawn");

            rooms.Add(spawnRoom);
        }

        if(level == 2)
        {
            //Spawn=0
            //Key=1
            //Empty=2
            //Goal=3

            Room spawnRoom = new Room();
            spawnRoom.items.Add("spawn");
            spawnRoom.doors.AddRange(new string[]{"north:1 key:1", "east:2", "south:3 exit:1"});

            Room northRoom = new Room();
            northRoom.doors.Add("south:0 spawn:1 exit:2");
            northRoom.items.Add("key");

            Room eastRoom = new Room();
            eastRoom.doors.Add("west:0 spawn:1 exit:2 key:2");

            Room southRoom = new Room();
            southRoom.doors.Add("north:0 spawn:1 key:2");
            southRoom.items.Add("exit");

            rooms.Add(spawnRoom);
            rooms.Add(northRoom);
            rooms.Add(eastRoom);
            rooms.Add(southRoom);
        }
    }
}
