﻿using UnityEngine;
using System;
using System.Collections.Generic; 		//Allows us to use Lists.
using Random = UnityEngine.Random; 		//Tells Random to use the Unity Engine random number generator.

namespace Completed
	
{
	
	public class BoardManager : MonoBehaviour
	{		
		public int columns = 8; 										//Number of columns in our game board.
		public int rows = 8;											//Number of rows in our game board.


		public GameObject[] floorTiles;									//Array of floor prefabs.
		public GameObject[] wallTiles;									//Array of wall prefabs.
		public GameObject[] outerWallTiles;                             //Array of outer tile prefabs.

        public GameObject key;                                          //Prefab for apples/key
        public GameObject spawn;                                        //Prefab for level spawn
        public GameObject exit;											//Prefab for exit.
        public GameObject door;                                         //Prefab for doors in a room
        public GameObject player;

        private List<GameObject> instantiatedObjects = new List<GameObject>();

        //keep the hirachy clean
		private Transform boardHolder;									//A variable to store a reference to the transform of our Board object.
		private List <Vector3> gridPositions = new List <Vector3> ();   //A list of possible locations to place tiles.

        private AudioClip keySound;
        private AudioClip exitSound;
        private AudioClip spawnSound;
		
		//Clears our list gridPositions and prepares it to generate a new board.
		void InitialiseList ()
		{
			//Clear our list gridPositions.
			gridPositions.Clear ();
			
			//Loop through x axis (columns).
			for(int x = 1; x < columns-1; x++)
			{
				//Within each column, loop through y axis (rows).
				for(int y = 1; y < rows-1; y++)
				{
					//At each index add a new Vector3 to our list with the x and y coordinates of that position.
					gridPositions.Add (new Vector3(x, y, 0f));
				}
			}
		}
		
		
		//Sets up the outer walls and floor (background) of the game board.
		void BoardSetup ()
		{
			//Instantiate Board and set boardHolder to its transform.
			boardHolder = new GameObject ("Board").transform;
			
			//Loop along x axis, starting from -1 (to fill corner) with floor or outerwall edge tiles.
			for(int x = -1; x < columns + 1; x++)
			{
				//Loop along y axis, starting from -1 to place floor or outerwall tiles.
				for(int y = -1; y < rows + 1; y++)
				{
					//Choose a random tile from our array of floor tile prefabs and prepare to instantiate it.
					GameObject toInstantiate = floorTiles[Random.Range (0,floorTiles.Length)];					
					//Check if we current position is at board edge, if so choose a random outer wall prefab from our array of outer wall tiles.
					if(x == -1 || x == columns || y == -1 || y == rows)
						toInstantiate = outerWallTiles [Random.Range (0, outerWallTiles.Length)];
					//Instantiate the GameObject instance using the prefab chosen for toInstantiate at the Vector3 corresponding to current grid position in loop, cast it to GameObject.
					GameObject instance =
						Instantiate (toInstantiate, new Vector3 (x, y, 0f), Quaternion.identity) as GameObject;					
					//Set the parent of our newly instantiated object instance to boardHolder, this is just organizational to avoid cluttering hierarchy.
					instance.transform.SetParent (boardHolder);

                    instantiatedObjects.Add(instance);
				}
			}
		}

        //SetupScene initializes our level and calls the previous functions to lay out the game board
        public void SetupScene (Room room)
		{
            TextAsset txt = Resources.Load<TextAsset>("config");
            string[] soundNames = txt.text.Split('\n');
            keySound = Resources.Load<AudioClip>(soundNames[0].Trim());
            exitSound = Resources.Load<AudioClip>(soundNames[1].Trim());
            spawnSound = Resources.Load<AudioClip>(soundNames[2].Trim());

            spawn.GetComponent<AudioSource>().clip = spawnSound;
            exit.GetComponent<AudioSource>().clip = exitSound;
            key.GetComponent<AudioSource>().clip = keySound;

            //Creates the outer walls and floor.
            BoardSetup();

            //Reset our list of gridpositions.
            InitialiseList();

            foreach (string item in room.items)
            {
                if(item == "key" && !Player.hasKey)
                {
                    GameObject instance = Instantiate(key, new Vector3(1, rows-1), Quaternion.identity);
                    instantiatedObjects.Add(instance);
                }
                else if(item == "exit")
                {
                    GameObject instance = Instantiate(exit, new Vector3(columns - 1, rows - 1, 0f), Quaternion.identity);
                    instantiatedObjects.Add(instance);
                }
                else if(item == "spawn")
                {
                    GameObject instance = Instantiate(spawn, new Vector3(1, 1, 0f), Quaternion.identity);
                    instantiatedObjects.Add(instance);
                }
            }

            foreach(string newDoor in room.doors)
            {
                string[] parts = newDoor.Split();
                string[] direction = parts[0].Split(':');

                if(direction[0] == "north")
                {
                    GameObject obj = Instantiate(door, new Vector3(columns / 2, rows - 1, 0f), Quaternion.identity);
                    Door northDoor = obj.GetComponent<Door>();
                    northDoor.nextRoom = Int32.Parse(direction[1]);
                    addSoundsToDoor(parts, northDoor);
                    instantiatedObjects.Add(obj);
                }
                else if (direction[0] == "east")
                {
                    GameObject obj = Instantiate(door, new Vector3(columns - 1, rows / 2, 0f), Quaternion.identity);
                    Door eastDoor = obj.GetComponent<Door>();
                    eastDoor.nextRoom = Int32.Parse(direction[1]);
                    addSoundsToDoor(parts, eastDoor);
                    instantiatedObjects.Add(obj);
                }
                else if (direction[0] == "south")
                {
                    GameObject obj = Instantiate(door, new Vector3(columns / 2, 1, 0f), Quaternion.identity);
                    Door southDoor = obj.GetComponent<Door>();
                    southDoor.nextRoom = Int32.Parse(direction[1]);
                    addSoundsToDoor(parts, southDoor);
                    instantiatedObjects.Add(obj);
                }
                else if (direction[0] == "west")
                {
                    GameObject obj = Instantiate(door, new Vector3(1, rows / 2, 0f), Quaternion.identity);
                    Door westDoor = obj.GetComponent<Door>();
                    westDoor.nextRoom = Int32.Parse(direction[1]);
                    addSoundsToDoor(parts, westDoor);
                    instantiatedObjects.Add(obj);
                }
            }

            GameObject playerInstance = Instantiate(player, new Vector3(columns / 2, rows / 2, 0f), Quaternion.identity);
            instantiatedObjects.Add(playerInstance);
		}

        private void addSoundsToDoor(string[] parts, Door door)
        {
            int i = 1;
            while(i <= parts.Length - 1)
            {
                Sound s = new Sound();
                string[] item = parts[i].Split(':');

                if (item[0] == "key" && !Player.hasKey)
                    s.clip = keySound;
                else if (item[0] == "exit")
                    s.clip = exitSound;
                else if (item[0] == "spawn")
                    s.clip = spawnSound;

                s.loop = true;
                s.distance = Int32.Parse(item[1]);
                door.AddSound(s);
                i++;
            }
        }

        public void ClearRoom()
        {
            foreach(GameObject obj in instantiatedObjects)
            {
                Destroy(obj);
            }
        }
	}
}
