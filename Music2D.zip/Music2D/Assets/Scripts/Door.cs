﻿using UnityEngine.Audio;
using UnityEngine;
using System.Collections.Generic;

public class Door : MonoBehaviour {

    public int nextRoom;
    public string direction;

    public float sourceMasterVolumeControl;
    List<Sound> sounds = new List<Sound>();

    public void AddSound(Sound sound)
    {
        sound.source = gameObject.AddComponent<AudioSource>();
        sound.source.clip = sound.clip;
        sound.source.loop = sound.loop;
        sound.source.volume = sourceMasterVolumeControl / sound.distance;
        sound.source.spatialBlend = 1;
        sound.source.maxDistance = 5;
        sound.source.rolloffMode = AudioRolloffMode.Linear;

        sounds.Add(sound);
        sounds.Find(s=> s == sound).source.Play();
    }

    void Stop()
    {
        foreach (Sound s in sounds)
        {
            s.source.Stop();
        }
    }

}
